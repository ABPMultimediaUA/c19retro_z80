// Data created with Img2CPC - (c) Retroworks - 2007-2017
#ifndef _SRC_ASSETS_IMG_HEART_HEART_H_
#define _SRC_ASSETS_IMG_HEART_HEART_H_

#include <types.h>
#define SP_HEART_W 4
#define SP_HEART_H 16
extern const u8 sp_heart[4 * 16];

#endif
